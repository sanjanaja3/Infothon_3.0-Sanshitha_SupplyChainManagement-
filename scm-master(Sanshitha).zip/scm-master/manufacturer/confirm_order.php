<?php
    // Enable error reporting for development
    // error_reporting(E_ALL);
    // ini_set('display_errors', 1);

    require("../includes/config.php");
    session_start();

    // Check if user is logged in
    if(isset($_SESSION['manufacturer_login'])) {
        // Validate and sanitize $_GET['id']
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Initialize variables
        $availProId = [];
        $availQuantity = [];
        $orderProId = [];
        $orderQuantity = [];

        // Fetch available quantities of products in the order
        $queryAvailQuantity = "SELECT p.pro_id AS pro_id, p.quantity AS quantity
                              FROM order_items o
                              INNER JOIN products p ON p.pro_id = o.pro_id
                              WHERE o.order_id = '$id' AND p.quantity IS NOT NULL";
        $resultAvailQuantity = mysqli_query($con, $queryAvailQuantity);

        while($rowAvailQuantity = mysqli_fetch_array($resultAvailQuantity)){
            $availProId[] = $rowAvailQuantity['pro_id'];
            $availQuantity[] = $rowAvailQuantity['quantity'];
        }

        // Fetch ordered quantities of products
        $queryOrderQuantity = "SELECT quantity AS q, pro_id AS p FROM order_items WHERE order_id='$id'";
        $resultOrderQuantity = mysqli_query($con, $queryOrderQuantity);

        while($rowOrderQuantity = mysqli_fetch_array($resultOrderQuantity)){
            $orderProId[] = $rowOrderQuantity['p'];
            $orderQuantity[] = $rowOrderQuantity['q'];
        }

        // Update product quantities
        foreach(array_combine($orderProId, $orderQuantity) as $p => $q) {
            foreach(array_combine($availProId, $availQuantity) as $proId => $quantity) {
                if($p == $proId) {
                    $total = $quantity - $q;
                    if($total >= 0 ) {
                        $queryUpdateQuantity = "UPDATE products SET quantity='$total' WHERE pro_id='$proId'";
                        $result = mysqli_query($con, $queryUpdateQuantity);
                        if(!$result) {
                            echo "<script> alert(\"Error updating product quantities\"); </script>";
                            exit;
                        }
                    }
                }
            }
        }

        // Check if all products were updated successfully
        if(isset($result) && $result) {
            // Confirm the order
            $queryConfirm = "UPDATE orders SET approved=1 WHERE order_id='$id'";
            if(mysqli_query($con, $queryConfirm)) {
                echo "<script> alert(\"Order has been confirmed\"); </script>";
            } else {
                echo "<script> alert(\"There was some issue in approving order.\"); </script>";
            }
        } else {
            echo "<script> alert(\"You don't have enough stock to approve this order\"); </script>";
        }

        // Redirect to view_orders.php after processing
        echo "<script> window.location.href = 'view_orders.php'; </script>";
    } else {
        header('Location:../index.php');
    }
?>
