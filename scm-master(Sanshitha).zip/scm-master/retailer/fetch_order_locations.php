<?php
require("../includes/config.php");

$query = "SELECT r.address
FROM retailer r
JOIN `orders` o ON r.retailer_id = o.retailer_id
WHERE status = 0";
$result = mysqli_query($con, $query);

$address = array();

while ($row = mysqli_fetch_assoc($result)) {
    $address[] = $row;
}

echo json_encode($address);
?>