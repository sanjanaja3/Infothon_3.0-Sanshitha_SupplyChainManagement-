<?php

// Function to generate AI bot responses based on user input
function getBotResponse($userInput) {
    // Define responses based on user queries
    $responses = [
        "hi" => "Hi there! How can I assist you today?",
        "how much time does it take" => "It usually takes about 2 hours.",
        "at what time will i get it" => "You can expect it around 1pm.",
        "bye" => "Goodbye! Have a great day!",
        // Add more responses as needed
    ];

    // Convert user input to lowercase for case-insensitive matching
    $userInputLower = strtolower($userInput);

    // Check if the user input matches any predefined response
    if (array_key_exists($userInputLower, $responses)) {
        return $responses[$userInputLower];
    } else {
        return "I'm sorry, I didn't quite catch that. Can you please rephrase?";
    }
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve the raw JSON input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    // Check if 'userInput' field is present and not empty
    if (isset($data['userInput']) && !empty($data['userInput'])) {
        // Extract user input from the JSON data
        $userInput = trim($data['userInput']); // Trim whitespace

        // Get AI bot response based on user input
        $botResponse = getBotResponse($userInput);

        // Prepare JSON response
        $response = [
            'botResponse' => $botResponse
        ];

        // Send JSON response with HTTP status 200 (OK)
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // If 'userInput' field is missing or empty, return a 400 error
        http_response_code(400);
        echo json_encode(['error' => 'Missing or empty userInput field']);
    }
} else {
    // If the request method is not POST, return a 405 error
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
}
?>
